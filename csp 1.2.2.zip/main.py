# no comments for you haha l bozo

def main():
    #-----import statements-----
    import turtle
    import random
    import leaderboard as lb

    #-----game configuration----
    lBFileName = 'kekw.txt'
    player_name = input('player name? ').lower()

    screen = turtle.Screen()
    tSize = 20000
    tShape = 'turtle'
    tColor = 'green'

    fontSetup = ('Arial', 10, 'normal')

    global Score
    Score = 0

    global timer, timer_up
    timer = 30
    counter_interval = 1000
    timer_up = False


    #-----initialize turtle-----
    spote = turtle.Turtle()
    spote.shape(tShape); spote.shapesize(tSize); spote.fillcolor(tColor); spote.speed(0); spote.penup()

    scoreWriter = turtle.Turtle()
    scoreWriter.hideturtle(); scoreWriter.pencolor('black'); scoreWriter.speed(0); scoreWriter.penup()
    scoreWriter.goto(-375, 275)


    counter = turtle.Turtle()
    counter.pencolor('black'); counter.speed(0); counter.penup(); counter.hideturtle()
    counter.goto(-375, 250)

    #-----game functions--------
    def changePos():
        newX, newY = random.randint(-400, 400), random.randint(-300, 300)
        spote.hideturtle()
        spote.goto(newX, newY)
        spote.showturtle()
    
    def updateScore():
        global Score
        Score += 1

        scoreWriter.clear()
        scoreWriter.write('score:' + str(Score), False, "CENTER", fontSetup)

    def spoteClicked(x, y):
        global timer

        if timer > 0:
            changePos()
            updateScore()
            spote.turtlesize()

        else:
            spote.hideturtle()

    # manages the leaderboard for top 5 scorers
    def manage_leaderboard():

        global Score
        
        # get the names and scores from the leaderboard file
        leader_names_list = lb.get_names(lBFileName)
        leader_scores_list = lb.get_scores(lBFileName)

        # show the leaderboard with or without the current player
        if (len(leader_scores_list) < 5 or Score >= leader_scores_list[4]):
            lb.update_leaderboard(lBFileName, leader_names_list, leader_scores_list, player_name, Score)
            lb.draw_leaderboard(True, leader_names_list, leader_scores_list, spote, Score)

        else:
            lb.draw_leaderboard(False, leader_names_list, leader_scores_list, spote, Score)


    def countdown():
        global timer, timer_up
        counter.clear()
        if timer <= 0:
            counter.write("Time's Up", False, "CENTER", fontSetup)
            timer_up = True
            manage_leaderboard()
        else:
            counter.write("Time: " + str(timer), False, "CENTER", fontSetup)
            timer -= 1
            counter.getscreen().ontimer(countdown, counter_interval) 

    
    #-----events----------------
    
    countdown()
    
    spote.onclick(spoteClicked)

    screen.mainloop()

if __name__ == '__main__':
    main()